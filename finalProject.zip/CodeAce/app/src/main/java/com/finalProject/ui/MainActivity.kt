package com.finalProject.ui

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.Menu
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.setupWithNavController
import com.finalProject.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import android.content.Context
import com.finalProject.R


class MainActivity : AppCompatActivity() {

    object Globals{
        var appContext: Context? = null
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private var isAddMenuItemVisible = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize appContext
        Globals.appContext = applicationContext

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.navHostMain) as NavHostFragment
        navController = navHostFragment.navController

        //set up the ToolBar
        val appBarConfiguration = AppBarConfiguration(navController.graph)
        binding.toolbar.setupWithNavController(navController,appBarConfiguration)
        setSupportActionBar(binding.toolbar)

        NavigationUI.setupActionBarWithNavController(this, navController)

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.mainActivityBottomNavigationView)
        NavigationUI.setupWithNavController(bottomNavigationView, navController)

        // Ensure the initial state of the top menu items reflects the value of isAddMenuItemVisible
        invalidateOptionsMenu()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (isLoggedIn()) {
            menuInflater.inflate(R.menu.bottom_nav_menu, menu)
            if (isAddMenuItemVisible) {
                menuInflater.inflate(R.menu.top_menu, menu)
            }
        }
        return super.onCreateOptionsMenu(menu)
    }

    fun setAddMenuItemVisibility(isVisible: Boolean) {
        isAddMenuItemVisible = isVisible
        invalidateOptionsMenu()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                navController.navigateUp()
                true
            }
            else -> NavigationUI.onNavDestinationSelected(item, navController)
        }
    }

    private fun isLoggedIn(): Boolean {
        return FirebaseAuth.getInstance().currentUser != null
    }

    fun setBottomBarVisibility(isVisible: Boolean) {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.visibility = if (isVisible) View.VISIBLE else View.GONE
    }

}