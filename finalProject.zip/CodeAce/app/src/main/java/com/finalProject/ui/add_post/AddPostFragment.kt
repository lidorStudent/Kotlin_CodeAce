package com.finalProject.ui.add_post

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.finalProject.R
import com.finalProject.data.models.FirebasePostModel
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.data.models.Post
import com.finalProject.databinding.FragmentAddPostBinding
import com.finalProject.ui.all_posts.PostViewModel
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.UUID


class AddPostFragment : Fragment() {

    private val viewModel: PostViewModel by viewModels {
        PostViewModel.PostViewModelFactory(FirebaseUserModel(), FirebasePostModel())
    }
    private var binding: FragmentAddPostBinding by autoCleared()
    // uri for selected image
    private var imageUri: Uri? = null
    // post details
    private lateinit var postPublisher: String
    private lateinit var publisherEmail: String
    private lateinit var photo: String
    private lateinit var bm : Bitmap

    // launcher for picking an image from the device
    private val pickItemLauncher: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) {
            if (it != null) {
                binding.resultImage.setImageURI(it)
                requireActivity().contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                imageUri = it
            } else {
                findNavController().popBackStack(R.id.addPostFragment, false)
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentAddPostBinding.inflate(inflater, container, false)
        setupUI()
        // observe curr user data
        viewModel.currentUser.observe(viewLifecycleOwner) { resource ->
            when (resource) {
                is Resource.Loading -> binding.progressBar.isVisible = true
                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    val user = resource.data
                    if(user != null){
                        postPublisher = user.name
                        publisherEmail = user.email
                    }
                }
                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(), resource.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
        // set click listener for the post button
        binding.btnPost.setOnClickListener {
            val topic = binding.editTextTopicName.text.toString()
            val additionalText = binding.editTextAdditonalText.text.toString()
            viewModel.uploadImage(imageUri!!, this)
            viewModel.uploadImage.observe(viewLifecycleOwner) {
                photo = it.data.toString()
                Log.d("maya", "photo: "+ it.data)
                if (topic.isBlank() || additionalText.isBlank() || photo.isEmpty()) {
                    Toast.makeText(
                        requireContext(),
                        R.string.fill_all,
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    if (::postPublisher.isInitialized && ::publisherEmail.isInitialized) {
                        val ID: String = UUID.randomUUID().toString()
                        Log.i("email", publisherEmail)
                        val post =
                            Post(ID, postPublisher, publisherEmail, topic, additionalText, photo)
                        Log.i("post initiated", "")
                        viewModel.addPost(post)
                        Log.i("viewModel.addPost", "")
                        findNavController().navigate(R.id.action_addPostFragment_to_allPostsFragment)
                    } else {
                        Toast.makeText(
                            requireContext(),
                            R.string.failed_userInfo,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
        // set click listener for the upload image button
        binding.btnUploadImage.setOnClickListener {
            pickItemLauncher.launch(arrayOf("image/*"))
        }
        // set click listener for the cancel button
        binding.btnCancel.setOnClickListener {
            findNavController().navigate(R.id.action_addPostFragment_to_allPostsFragment)
        }

        return binding.root
    }
    // set up UI components and listemers
    private fun setupUI() {
        val bottomNavigationView =
            requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.allPostsFragment -> {
                    findNavController().navigate(R.id.action_addPostFragment_to_allPostsFragment)
                    true
                }
                R.id.myPostsFragment -> {
                    findNavController().navigate(R.id.action_addPostFragment_to_myPostsFragment)
                    true
                }
                R.id.profileFragment -> {
                    findNavController().navigate(R.id.action_addPostFragment_to_profileFragment)
                    true
                }
                else -> false
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu.clear()
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        checkAndUpdateScrollViewIfNeeded()
    }
    // check if the scrollView is needed
    private fun checkAndUpdateScrollViewIfNeeded() {
        binding.root.post {
            val isScrollNeeded = binding.root.height > resources.displayMetrics.heightPixels

            if (isScrollNeeded) {
                if (binding.root.parent is ViewGroup) {
                    val parentView = binding.root.parent as ViewGroup
                    parentView.removeView(binding.root)

                    val scrollView = ScrollView(requireContext())
                    scrollView.layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scrollView.addView(binding.root)

                    parentView.addView(scrollView)
                }
            } else {
                if (binding.root.parent is ScrollView) {
                    val parentView = binding.root.parent as ViewGroup
                    parentView.removeView(binding.root)

                    val newParentView = parentView.parent as ViewGroup
                    newParentView.addView(binding.root)
                }
            }
        }
    }
}