package com.finalProject.ui.user

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.finalProject.R
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.databinding.FragmentProfileBinding
import com.finalProject.ui.MainActivity
import com.finalProject.utils.autoCleared
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.Locale

/**
 * A Fragment representing the user's profile.
 */
class ProfileFragment : Fragment() {
    // ViewModel for user data
    private val viewModel: UserViewModel by viewModels {
        UserViewModel.UserViewModelFactory(FirebaseUserModel())
    }
    // View binding for the profile fragment
    private var binding: FragmentProfileBinding by autoCleared()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Show the bottom bar and add menu item in the main
        (requireActivity() as MainActivity).setBottomBarVisibility(true)
        (requireActivity() as MainActivity).setAddMenuItemVisibility(true)
        // Observe the current user data
        viewModel.currentUser.observe(viewLifecycleOwner) {
            val user = it.data
            if (user != null) {
                // Set the user details in the views, with localization for Hebrew
                if(Locale.getDefault().language == "iw"){
                    binding.nameTextView.text = "שם: ${user.name}"
                    binding.emailTextView.text = "אימייל: ${user.email}"
                } else {
                    binding.nameTextView.text = "Name: ${user.name}"
                    binding.emailTextView.text = "Email: ${user.email}"
                }
                // Load the user image using Glide
                Glide.with(requireContext())
                    .load(user.image)
                    .centerCrop()
                    .into(binding.imageView2)
            } else {
                Log.e("ProfileFragment", "User details not found for email: $user.email")
                if(Locale.getDefault().language == "iw") {
                    view.findViewById<TextView>(R.id.emailTextView).text = "מייל: לא נמצא"
                    view.findViewById<TextView>(R.id.nameTextView).text = "שם: לא נמצא"
                } else{
                    view.findViewById<TextView>(R.id.emailTextView).text = "Email: Not found"
                    view.findViewById<TextView>(R.id.nameTextView).text = "Name: Not found"
                }
            }
        }
        // Set the click listener for the logout button
        binding.btnLogout.setOnClickListener {
            viewModel.signOut()
            logoutUser()
        }
        // Set the click listener for the edit button
        binding.btnEdit.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_editProfileFragment)
        }
        // Set up the bottom navigation view
        val bottomNavigationView =
            requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.allPostsFragment -> {
                    // Navigate to the user allPosts fragment
                    findNavController().navigate(R.id.action_profileFragment_to_allPostsFragment)
                    true
                }
                R.id.addPostFragment -> {
                    // Navigate to the add post fragment
                    findNavController().navigate(R.id.action_profileFragment_to_addPostFragment)
                    true
                }
                R.id.myPostsFragment -> {
                    findNavController().navigate(R.id.action_profileFragment_to_myPostsFragment)
                    true
                }
                else -> false
            }
        }
    }
    /**
     * Logs out the user and navigates to the login fragment.
     */
    private fun logoutUser() {
        Navigation.findNavController(requireView()).navigate(R.id.action_profileFragment_to_logInFragment)
    }
}