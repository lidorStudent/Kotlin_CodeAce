package com.finalProject.data.models

import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.finalProject.data.repostories.PostRepository
import com.finalProject.utils.Resource
import com.finalProject.utils.safeCall
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID


class FirebasePostModel : PostRepository{

    private val postRef = FirebaseFirestore.getInstance().collection("posts")
    private val imageStorage: FirebaseStorage = FirebaseStorage.getInstance()

    override suspend fun getPosts()= withContext(Dispatchers.IO) {
        safeCall {
            val res = postRef.get().await()
            val posts = res.toObjects(Post::class.java)
            Resource.Success(posts)
        }
    }
    override suspend fun getPostById(postId: String) = withContext(Dispatchers.IO) {
        safeCall {
            val res = postRef.whereEqualTo("postid", postId).get().await()
            val posts = res.toObjects(Post::class.java)
            Resource.Success(posts.first())
        }
    }
    override suspend fun addPost(post: Post) = withContext(Dispatchers.IO)  {
        safeCall {
            val addition = postRef.document(post.postid).set(post.Json).await()
            Resource.Success(addition)
        }
    }
    override suspend fun deletePost(post: Post) = withContext(Dispatchers.IO) {
        safeCall {
            val res = postRef.document(post.postid).delete().await()
            Resource.Success(res)
        }
    }
    override suspend fun updatePost(post: Post) = withContext(Dispatchers.IO) {
        safeCall {
            val update = postRef.document(post.postid).set(post.Json).await()
            Resource.Success(update)
        }
    }
    override suspend fun getAllUserPosts(userEmail: String) = withContext(Dispatchers.IO) {
        safeCall {
            val res = postRef.whereEqualTo("publisherEmail", userEmail).get().await()
            val posts = res.toObjects(Post::class.java)
            Resource.Success(posts)
        }
    }
    override suspend fun getPostsByPublisherEmail(publisherEmail: String) = withContext(Dispatchers.IO) {
        safeCall {
            val res = postRef.whereEqualTo("publisherEmail", publisherEmail).get().await()
            val posts = res.toObjects(Post::class.java)
            Resource.Success(posts)
        }
    }
    override fun getPostsLiveData(data: MutableLiveData<Resource<List<Post>>>) {
        data.postValue(Resource.Loading())

        postRef.orderBy("topicName")
            .addSnapshotListener{ snapshot, e ->
                if(e != null){
                    data.postValue(Resource.Error(e.localizedMessage ?: "Unknown Error"))
                }
                if (snapshot != null && !snapshot.isEmpty){
                    data.postValue(Resource.Success(snapshot.toObjects(Post::class.java)))
                }
                else{
                    data.postValue(Resource.Error("No Data"))
                }
            }
    }
    override fun getMyPostsLiveData(data: MutableLiveData<Resource<List<Post>>>, userEmail: String) : ListenerRegistration {
        data.postValue(Resource.Loading())

        return postRef.whereEqualTo("publisherEmail", userEmail)
            .orderBy("topicName")
            .addSnapshotListener { snapshot , e ->
                if(e != null) {
                    data.postValue(Resource.Error(e.localizedMessage ?: "Unknown error"))
                    return@addSnapshotListener
                }
                if (snapshot != null && !snapshot.isEmpty){
                    data.postValue(Resource.Success(snapshot.toObjects(Post::class.java)))
                }
                else {
                    data.postValue(Resource.Error("No Data"))
                }
            }
    }

    override suspend fun uploadImage(uri : Uri,  fm : Fragment) = withContext(Dispatchers.IO) {
        safeCall {
            Log.d("maya","Glide.loading: " + uri)
            var bm = Glide.with(fm)
                .asBitmap()
                .load(uri)
                .submit()
                .get()
                val outputStream = ByteArrayOutputStream()
                bm.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
                val data : ByteArray = outputStream.toByteArray()

                val storageRef = imageStorage.reference.child("images/${UUID.randomUUID()}.jpg")
            storageRef.putBytes(data).await()
            val res = storageRef.downloadUrl.await()
            Resource.Success(res)
        }
    }
}