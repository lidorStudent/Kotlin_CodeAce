import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.finalProject.data.models.Post
import com.finalProject.databinding.PostLayoutBinding
import com.bumptech.glide.Glide
import com.finalProject.R

/**
 * Adapter for managing and displaying a list of posts in a RecyclerView.
 *
 * @property callback Listener for handling post click and long-click events.
 */
class PostsRecyclerAdapter(private val callback: PostClickListener) : RecyclerView.Adapter<PostsRecyclerAdapter.PostViewHolder>() {
    // List to hold the posts
    private val posts = ArrayList<Post>()
    /**
     * Sets the posts to be displayed in the adapter.
     * Clears the current list and adds the new posts.
     *
     * @param posts Collection of posts to be added.
     */
    fun setPosts(posts: Collection<Post>){
        this.posts.clear()
        this.posts.addAll(posts)
        notifyDataSetChanged()
    }
    /**
     * Interface for handling post click and long-click events.
     */
    interface PostClickListener {
        fun onPostClick(post: Post)
        fun onPostLongClick(post: Post)
    }
    /**
     * ViewHolder class for holding and binding the post views.
     *
     * @property binding View binding for the post layout.
     */
    inner class PostViewHolder(private val binding: PostLayoutBinding) :
        RecyclerView.ViewHolder(binding.root), View.OnClickListener, View.OnLongClickListener {

        init {
            // Set click and long-click listeners for the root view
            binding.root.setOnClickListener(this)
            binding.root.setOnLongClickListener(this)
        }
        /**
         * Handles the click event on a post item.
         */
        override fun onClick(p0: View?) {
            callback.onPostClick(posts[adapterPosition])
        }
        /**
         * Handles the long-click event on a post item.
         */
        override fun onLongClick(p0: View?): Boolean {
            callback.onPostLongClick(posts[adapterPosition])
            return false
        }
        /**
         * Binds the post data to the views.
         *
         * @param post Post data to be bound.
         */
        fun bind(post: Post) {
            binding.postTopic.text = post.topicName
            binding.additonalText.text = post.additionalText
            val imageUrl = post.imageUrl
            if (!imageUrl.isNullOrEmpty()) {
                // Load the post image using Glide
                Glide.with(binding.root)
                    .load(imageUrl)
                    .fitCenter()
                    .into(binding.postImage)
            } else {
                // Load a default image if no image URL is provided
                Glide.with(binding.root)
                    .load(R.drawable.code_icon)
                    .fitCenter()
                    .into(binding.postImage)
            }
        }
    }

    /**
     * Returns the post at the specified position.
     *
     * @param position Position of the post in the list.
     * @return Post at the specified position.
     */
    fun postAt(position: Int) = posts[position]

    /**
     * Inflates the layout for a post item and creates a ViewHolder.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = PostViewHolder(
        PostLayoutBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
    )

    /**
     * Binds the post data to the ViewHolder.
     */
    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        holder.bind(post)
    }

    /**
     * Returns the total number of posts in the adapter.
     */
    override fun getItemCount(): Int {
        return posts.size
    }
}