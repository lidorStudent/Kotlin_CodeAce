package com.finalProject.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    val name: String,
    @PrimaryKey val email: String,
    val image: String){

    constructor() : this("", "", "")

    companion object {
        const val NAME_KEY = "name"
        const val EMAIL_KEY = "email"
        const val IMAGE_KEY = "image"
        const val GET_LAST_UPDATED = "get_last_updated"

        fun fromJSON(json: Map<String, Any>): User {
            val name = json[NAME_KEY] as? String ?: ""
            val email = json[EMAIL_KEY] as? String ?: ""
            val image = json[User.IMAGE_KEY] as? String ?: ""
            val user = User(name, email, image)

            return user
        }
    }

    val json: Map<String, Any>
        get() {
            return hashMapOf(
                NAME_KEY to name,
                EMAIL_KEY to email,
                IMAGE_KEY to image,
            )
        }
}

