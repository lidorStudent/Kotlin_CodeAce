package com.finalProject.ui.user

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.finalProject.databinding.ItemImageBinding

class ImageSelectionAdapter(
    private val imageUrls: List<String>, // List of image URLs to be displayed
    private val onItemClick: (String) -> Unit // Lambda function to handle item click events
) : RecyclerView.Adapter<ImageSelectionAdapter.ImageViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        // Inflate the ItemImageBinding layout and return a new ImageViewHolder instance
        val binding = ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ImageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        // Get the image URL for the current position
        val imageUrl = imageUrls[position]
        Log.d("ImageSelectionAdapter", "Image URL: $imageUrl")
        // Load the image into the ImageView using Glide
        Glide.with(holder.itemView)
            .load(imageUrl)
            .into(holder.binding.imageView)
        // Set an OnClickListener on the itemView to handle item click events
        holder.itemView.setOnClickListener { onItemClick(imageUrl) }
    }

    override fun getItemCount(): Int {
        // Return the size of the imageUrls list
        return imageUrls.size
    }
    // ViewHolder class to hold a single item view
    inner class ImageViewHolder(val binding: ItemImageBinding) : RecyclerView.ViewHolder(binding.root)
}
