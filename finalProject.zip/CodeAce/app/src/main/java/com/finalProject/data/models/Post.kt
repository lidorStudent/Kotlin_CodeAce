package com.finalProject.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class Post(
    @PrimaryKey val postid: String ="",
    val publisher: String? ="",
    val publisherEmail: String = "",
    val topicName:String ="",
    val additionalText:String = "",
    val imageUrl : String = "",
) {

    companion object {
        const val id_KEY = "postid"
        const val PUBLISHER_KEY = "publisher"
        const val EMAIL_KEY = "publisherEmail"
        const val TOPIC_NAME_KEY = "topicName"
        const val ADDITIONAL_TEXT_KEY = "additionalText"
        const val IMAGE_KEY = "imageUrl"


        fun fromJSON(json: Map<String, Any>): Post {
            val postid = json[id_KEY] as? String ?: ""
            val publisher = json[PUBLISHER_KEY] as? String ?: ""
            val publisherEmail = json[EMAIL_KEY] as? String ?:""
            val topicName = json[TOPIC_NAME_KEY] as? String ?: ""
            val additionalText = json[ADDITIONAL_TEXT_KEY] as? String ?: ""
            val imageUrl = json[IMAGE_KEY] as? String ?: ""
            val post = Post(postid, publisher,publisherEmail, topicName,additionalText, imageUrl)
            return post
        }
    }

    val Json: Map<String, Any>
        get() {
            return hashMapOf(
                id_KEY to postid,
                PUBLISHER_KEY to publisher!!,
                EMAIL_KEY to publisherEmail,
                TOPIC_NAME_KEY to topicName,
                ADDITIONAL_TEXT_KEY to additionalText,
                IMAGE_KEY to imageUrl!!
            )
        }
}