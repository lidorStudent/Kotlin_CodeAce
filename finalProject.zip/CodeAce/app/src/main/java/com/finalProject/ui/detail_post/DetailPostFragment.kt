package com.finalProject.ui.detail_post

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.finalProject.R
import com.finalProject.data.models.FirebasePostModel
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.data.models.Post
import com.finalProject.databinding.FragmentDetailPostBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.finalProject.ui.all_posts.PostViewModel
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared

/**
 * This fragment displays the details of a selected post.
 * It allows the user to view the post's content, and if the user is the publisher of the post,
 * it also provides options to edit or delete the post.
 */
class DetailPostFragment : Fragment() {
    // Retrieve the post ID from the navigation arguments
    private val args: DetailPostFragmentArgs by navArgs()
    // Binding object for the fragment's layout
    private var binding: FragmentDetailPostBinding by autoCleared()
    // ViewModel instance for managing post-related data
    private val viewModel: PostViewModel by viewModels {
        PostViewModel.PostViewModelFactory(FirebaseUserModel(), FirebasePostModel())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentDetailPostBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val postId = args.postId
        var currentPost: Post? = null
        // Fetch the post details from the ViewModel
        viewModel.getPostById(postId)
        viewModel.chosenPost.observe(viewLifecycleOwner) {
            when(it){
                is Resource.Success ->{
                    binding.progressBar.isVisible = false
                    currentPost = it.data
                    // Update the UI with the post details
                    binding.textViewTopic.text = currentPost?.topicName
                    binding.textViewcontact.text = currentPost?.additionalText
                    Glide.with(requireContext()).load(currentPost?.imageUrl).into(binding.imageViewPost)
                    // Set up the edit and delete button click listeners
                    binding.buttonEdit.setOnClickListener {
                        val action =
                            DetailPostFragmentDirections.actionDetailPostFragmentToEditPostFragment(postId)
                        findNavController().navigate(action)
                    }
                    binding.buttonDelete.setOnClickListener {
                        // Delete the post and navigate back
                        viewModel.deletePost(currentPost!!)
                    }
                    // Check if the current user is the publisher of the post
                    viewModel.currentUser.observe(viewLifecycleOwner) {
                        when (it) {
                            is Resource.Loading -> {
                                binding.progressBar.isVisible = true
                            }
                            is Resource.Success -> {
                                binding.progressBar.isVisible = false
                                val userEmail = it.data?.email

                                Log.d("maya", "userEmail: " + userEmail)
                                Log.d ("maya", "publisherEmail: " + currentPost?.publisherEmail)
                                if (userEmail == currentPost?.publisherEmail) {
                                    // If the user is the publisher, show the edit and delete buttons
                                    binding.progressBar.isVisible = false
                                    binding.buttonEdit.isVisible = true
                                    binding.buttonDelete.isVisible = true
                                    binding.textViewCannotEditDelete.isVisible = false
                                } else {
                                    // If the user is not the publisher, hide the edit and delete buttons
                                    binding.progressBar.isVisible = false
                                    binding.buttonEdit.isVisible = false
                                    binding.buttonDelete.isVisible = false
                                    binding.textViewCannotEditDelete.isVisible = false

                                }
                            }

                            is Resource.Error -> {
                                binding.progressBar.isVisible = false
                                Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                }
                is Resource.Error -> {
                    Log.d("maya", "error  " + it.message )
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Observe the deletePost LiveData and handle the result
        viewModel.deletePost.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                }
                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),R.string.post_deleted,Toast.LENGTH_SHORT).show()
                    val action =
                        DetailPostFragmentDirections.actionDetailPostFragmentToAllPostsFragment()
                    findNavController().navigate(action)
                }
                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }

            }
        }
        // Set up the bottom navigation view
        val bottomNavigationView =
            requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.allPostsFragment -> {
                    // Navigate to the user allPosts fragment
                    findNavController().navigate(R.id.action_detailPostFragment_to_allPostsFragment)
                    true
                }
                R.id.addPostFragment -> {
                    // Navigate to the add post fragment
                    findNavController().navigate(R.id.action_detailPostFragment_to_addPostFragment)
                    true
                }
                R.id.myPostsFragment ->{
                    findNavController().navigate(R.id.action_detailPostFragment_to_myPostsFragment)
                    true
                }
                R.id.profileFragment -> {
                    // Navigate to the profile fragment
                    findNavController().navigate(R.id.action_detailPostFragment_to_profileFragment)
                    true
                }
                else -> false
            }
        }
    }
}