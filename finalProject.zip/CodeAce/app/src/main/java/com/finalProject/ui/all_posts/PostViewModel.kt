package com.finalProject.ui.all_posts

import androidx.lifecycle.*
import android.net.Uri
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import com.finalProject.data.models.Post
import com.finalProject.data.models.User
import com.finalProject.data.repostories.PostRepository
import com.finalProject.data.repostories.UserRepository
import com.finalProject.utils.Resource
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.launch

/**
* This ViewModel class is responsible for managing the data and operations related to posts.
* It interacts with the [UserRepository] and [PostRepository] to perform CRUD operations on posts
* and retrieve the current user's information.
*/
class PostViewModel(private val userRep:UserRepository, private val postRep:PostRepository): ViewModel(){
    // LiveData objects to hold the current user, posts, my posts, chosen post, add/delete/update post operations, and image upload status
    private val _currentUser = MutableLiveData<Resource<User>>()
    val currentUser : LiveData<Resource<User>> get() = _currentUser

    private val _posts: MutableLiveData<Resource<List<Post>>> = MutableLiveData()
    val posts: LiveData<Resource<List<Post>>> = _posts

    private val _myPosts: MutableLiveData<Resource<List<Post>>> = MutableLiveData()
    val myPosts: LiveData<Resource<List<Post>>> = _myPosts

    private val _chosenPost = MutableLiveData<Resource<Post>>()
    val chosenPost: LiveData<Resource<Post>> = _chosenPost

    private val _addPost = MutableLiveData<Resource<Void>>()
    val addPost: LiveData<Resource<Void>> = _addPost

    private val _deletePost = MutableLiveData<Resource<Void>>()
    val deletePost: LiveData<Resource<Void>> = _deletePost

    private val _updatePost = MutableLiveData<Resource<Void>>()
    val updatePost: LiveData<Resource<Void>> = _updatePost

    private val _getPost = MutableLiveData<Resource<Post>>()
    val getPost: LiveData<Resource<Post>> = _getPost

    private val _uploadImage = MutableLiveData<Resource<Uri>>()
    val uploadImage: LiveData<Resource<Uri>> = _uploadImage

    init{
        // Initialize the posts and my posts data
        postRep.getPostsLiveData(_posts)
        getUserEmail()?.let { postRep.getMyPostsLiveData(_myPosts, it) }
        // Get the current user data
        viewModelScope.launch {
            _currentUser.postValue(Resource.Loading())
            _currentUser.postValue(userRep.currentUser())
        }
    }

    /**
     * Refreshes the list of all posts by fetching the latest data from the repository.
     */
    fun refreshPosts(){
        viewModelScope.launch {
            Resource.Loading(_posts)
            postRep.getPostsLiveData(_posts)
        }
    }

    private var myPostsListenerRegistration : ListenerRegistration? = null

    /**
     * Refreshes the list of the current user's posts by fetching the latest data from the repository.
     */
    fun refreshMyPosts(){
        viewModelScope.launch {
            if(myPostsListenerRegistration != null) return@launch
            Resource.Loading(_myPosts)
            myPostsListenerRegistration = getUserEmail()?.let { postRep.getMyPostsLiveData(_myPosts, it) }
        }
    }

    /**
     * Retrieves the email of the current user from the user repository.
     */
    fun getUserEmail(): String? {
        return userRep.getUserEmail()
    }
    /**
     * Signs out the current user by calling the logout method in the user repository.
     */
    fun signOut(){
        userRep.logout()
    }
    /**
     * Adds a new post to the database by calling the addPost method in the post repository.
     */
    fun addPost(post: Post) {
        viewModelScope.launch{
            _addPost.postValue(Resource.Loading())
            _addPost.postValue(postRep.addPost(post))
        }
    }
    /**
     * Deletes a post from the database by calling the deletePost method in the post repository.
     */
    fun deletePost(post: Post) {
        viewModelScope.launch{
            _deletePost.postValue(Resource.Loading())
            _deletePost.postValue(postRep.deletePost(post))
        }
    }
    /**
     * Updates an existing post in the database by calling the updatePost method in the post repository.
     */
    fun updatePost(post: Post){
        viewModelScope.launch {
            _updatePost.postValue(Resource.Loading())
            _updatePost.postValue(postRep.updatePost(post))
        }
    }
    /**
     * Retrieves a post by its ID from the repository and stores it in the chosenPost LiveData.
     */
    fun getPostById(postId: String) {
        viewModelScope.launch {
            _chosenPost.postValue(Resource.Loading())
            _chosenPost.postValue(postRep.getPostById(postId))
        }
    }
    /**
     * Uploads an image to the server by calling the uploadImage method in the post repository.
     */
    fun uploadImage(uri: Uri, fm : Fragment){
        viewModelScope.launch {
            _uploadImage.postValue(postRep.uploadImage(uri,fm))
        }
    }
    /**
     * Factory class for creating instances of the PostViewModel.
     */
    class PostViewModelFactory(private val userRep: UserRepository,
                                  private val postRep: PostRepository)
        : ViewModelProvider.NewInstanceFactory() {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return PostViewModel(userRep, postRep) as T
        }
    }
    /**
     * Cleans up the listener registration when the ViewModel is cleared.
     */
    override fun onCleared() {
        super.onCleared()
        myPostsListenerRegistration?.remove()
    }
}