package com.finalProject.data.local_db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.finalProject.data.models.Post

@Database(entities = arrayOf(Post::class), version = 1, exportSchema = false)
abstract class PostDatabase : RoomDatabase() {
    abstract fun PostDao(): PostDao

    companion object {

        @Volatile
        private var instance: PostDatabase? = null

        fun getDatabase(context: Context) = instance ?: synchronized(PostDatabase::class.java) {
            Room.databaseBuilder(context.applicationContext,
                PostDatabase::class.java,"posts_database")
                .allowMainThreadQueries().build().also { instance = it }
        }
    }
}