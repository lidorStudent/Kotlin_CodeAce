package com.finalProject.ui.user

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.finalProject.R
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.databinding.FragmentLoginBinding
import com.finalProject.ui.MainActivity
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared


class LogInFragment : Fragment() {
    // Using the viewModels delegate to obtain an instance of the UserViewModel
    private val viewModel: UserViewModel by viewModels {
        UserViewModel.UserViewModelFactory(FirebaseUserModel())
    }
    // Using the autoCleared extension function to automatically clear the binding when the fragment's view is destroyed
    private var binding: FragmentLoginBinding by autoCleared()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflating the fragment_login layout and returning the root view
        binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Checking if the current activity is an instance of MainActivity
        // and setting the visibility of the bottom navigation bar and the add menu item
        (requireActivity() as? MainActivity)?.apply {
            setBottomBarVisibility(false)
            setAddMenuItemVisibility(false)
        }
        // Setting up a click listener for the "Register" button
        binding.ButtonRegister.setOnClickListener {
            findNavController().navigate(R.id.action_logInFragment_to_signUpFragment)
        }
        // Setting up a click listener for the "Sign In" button
        binding.BtnSignIn.setOnClickListener {
            val email = binding.SignInTextEmailAddress.editText?.text.toString().trim()
            val password = binding.SignInTextPassword.editText?.text.toString().trim()
            // Checking if either field is empty and displaying a toast message if so
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(context, R.string.fill_all, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Calling the signInUser method from the view model with the email and password
            viewModel.signInUser(email,password)
        }
        // Observing the userSignInStatus live data from the view model
        viewModel.userSignInStatus.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    // Showing the progress bar and disabling the "Sign In" button
                    binding.progressBar.isVisible = true
                    binding.BtnSignIn.isEnabled = false
                }
                is Resource.Success -> {
                    // Displaying a success toast message
                    Toast.makeText(requireContext(),R.string.login_successful, Toast.LENGTH_SHORT).show()
                    // Navigating to the AllPostsFragment
                    findNavController().navigate(R.id.action_logInFragment_to_allPostsFragment)
                    // Making the bottom navigation bar and add menu item visible
                    (requireActivity() as? MainActivity)?.apply {
                        setBottomBarVisibility(true)
                        setAddMenuItemVisibility(true)
                    }
                }
                is Resource.Error -> {
                    // Hiding the progress bar and enabling the "Sign In" button
                    binding.progressBar.isVisible = false
                    binding.BtnSignIn.isEnabled = true
                    // Displaying an error toast message
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }
            }
        }
        // Observing the currentUser live data from the view model
        viewModel.currentUser.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    // Showing the progress bar and disabling the "Sign In" button
                    binding.progressBar.isVisible = true
                    binding.BtnSignIn.isEnabled = false
                }
                is Resource.Success -> {
                    // Navigating to the AllPostsFragment
                    findNavController().navigate(R.id.action_logInFragment_to_allPostsFragment)
                    // Making the bottom navigation bar and add menu item visible
                    (requireActivity() as? MainActivity)?.apply {
                        setBottomBarVisibility(true)
                        setAddMenuItemVisibility(true)
                    }                }
                is Resource.Error -> {
                    // Hiding the progress bar and enabling the "Sign In" button
                    binding.progressBar.isVisible = false
                    binding.BtnSignIn.isEnabled = true
                }
            }
        }
    }
}