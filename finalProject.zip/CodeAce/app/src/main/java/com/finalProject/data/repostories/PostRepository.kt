package com.finalProject.data.repostories

import androidx.lifecycle.MutableLiveData
import com.finalProject.data.models.Post
import android.net.Uri
import androidx.fragment.app.Fragment
import com.finalProject.utils.Resource
import com.google.firebase.firestore.ListenerRegistration

interface PostRepository{
    suspend fun getPosts(): Resource<List<Post>>
    suspend fun getPostById(postId:String): Resource<Post>
    suspend fun getPostsByPublisherEmail(publisherEmail: String): Resource<List<Post>>
    suspend fun addPost(post: Post): Resource<Void>
    suspend fun updatePost(post: Post): Resource<Void>
    suspend fun deletePost(post: Post): Resource<Void>
    suspend fun getAllUserPosts(userEmail: String): Resource<List<Post>>
    suspend fun uploadImage(uri : Uri, fm : Fragment, ): Resource<Uri>
    fun getPostsLiveData(data: MutableLiveData<Resource<List<Post>>>)
    fun getMyPostsLiveData(data: MutableLiveData<Resource<List<Post>>>, userEmail: String) : ListenerRegistration
    }