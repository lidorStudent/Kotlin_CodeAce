package com.finalProject.data.local_db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.finalProject.data.models.User

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertUser(user: User)

    @Delete
    fun deleteUser(vararg user: User)

    @Query("SELECT * FROM users WHERE email =:email")
    fun getUserByEmail(email: String): LiveData<User>

    @Query("SELECT * from users ORDER BY name ASC")
    fun getUsers() : LiveData<List<User>>

    @Update
    fun updateUser(user: User)
}
