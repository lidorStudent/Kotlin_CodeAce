package com.finalProject.data.repostories

import com.finalProject.data.models.User
import com.finalProject.utils.Resource

interface UserRepository{

    suspend fun currentUser(): Resource<User>
    suspend fun login(email:String, password:String): Resource<User>
    suspend fun createUser(userName:String, userEmail:String, userPassword:String, userImageUrl: String): Resource<User>
    suspend fun updateUser(user: User): Resource<Void>
    suspend fun getUserByEmail(email: String): Resource<User>
    fun getUserEmail():String?
    fun logout()
}