package com.finalProject.ui.my_posts

import PostsRecyclerAdapter
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.finalProject.R
import com.finalProject.data.models.FirebasePostModel
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.data.models.Post
import com.finalProject.databinding.FragmentMyPostsBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.finalProject.ui.all_posts.PostViewModel
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * This fragment displays a list of posts created by the current user.
 * It allows the user to view, edit, and delete their own posts.
 */
class MyPostsFragment : Fragment() {
    // Binding object for the fragment's layout
    private var binding: FragmentMyPostsBinding by autoCleared()
    // ViewModel instance for managing post-related data
    private val viewModel: PostViewModel by viewModels {
        PostViewModel.PostViewModelFactory(FirebaseUserModel(), FirebasePostModel())
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMyPostsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Set up the RecyclerView with a LinearLayoutManager and the PostsRecyclerAdapter
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = PostsRecyclerAdapter(object : PostsRecyclerAdapter.PostClickListener{
            override fun onPostClick(post: Post) {
                // Navigate to the DetailPostFragment when a post is clicked
                post.postid.let {
                    val action =
                        MyPostsFragmentDirections.actionMyPostsFragmentToDetailPostFragment(
                            post.postid
                        )
                    findNavController().navigate(action)
                }
            }
            override fun onPostLongClick(post: Post) {
                // Navigate to the EditPostFragment when a post is long-clicked
                post.postid.let {
                    val action =
                        MyPostsFragmentDirections.actionMyPostsFragmentToEditPostFragment(
                            post.postid
                        )
                    findNavController().navigate(action)
                }
            }
        })
        // Set up the SwipeRefreshLayout to refresh the data when swiped down
        binding.pullToRefresh.setOnRefreshListener {
            reloadData()
        }
        // Observe the myPosts LiveData and update the RecyclerView accordingly
        viewModel.myPosts.observe(viewLifecycleOwner){
            when(it){
                is Resource.Loading ->{
                    binding.progressBar.isVisible = true
                }
                is Resource.Success ->{
                    binding.progressBar.isVisible = false
                    binding.pullToRefresh.isRefreshing = false
                    (binding.recycler.adapter as PostsRecyclerAdapter).setPosts(it.data!!)
                }
                is Resource.Error ->{
                    binding.progressBar.isVisible = false
                    binding.pullToRefresh.isRefreshing = false
                    Log.d("Err", it.message ?: "Unknown err")
                    Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
        // Observe the addPost LiveData and handle the result
        viewModel.addPost.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                }
                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),R.string.post_added,Toast.LENGTH_SHORT).show()
                }
                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }

            }
        }
        // Observe the deletePost LiveData and handle the result
        viewModel.deletePost.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                }
                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),R.string.post_deleted,Toast.LENGTH_SHORT).show()
                }
                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }

            }
        }
        // Set up the bottom navigation view
        setupBottomNavigation()
        // Set up the ItemTouchHelper for swiping to delete posts
        ItemTouchHelper(object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            )= makeFlag(ItemTouchHelper.ACTION_STATE_SWIPE, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT)

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }
            // Show a confirmation dialog before deleting the post
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val post = (binding.recycler.adapter as PostsRecyclerAdapter).postAt(viewHolder.adapterPosition)

                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.confirm_delete_title)
                    .setMessage(R.string.delete_item_message)
                    .setPositiveButton(R.string.delete) { dialog, _ ->
                        viewModel.deletePost(post)
                        dialog.dismiss()
                    }
                    .setNegativeButton(R.string.cancel) { dialog, _ ->
                        binding.recycler.adapter!!.notifyItemChanged(viewHolder.adapterPosition)
                        dialog.dismiss()
                    }
                    .setOnCancelListener {
                        binding.recycler.adapter!!.notifyItemChanged(viewHolder.adapterPosition)
                    }
                    .show()
            }
        }).attachToRecyclerView(binding.recycler)
    }

    /**
     * Sets up the bottom navigation view for navigating between different fragments.
     */
    private fun setupBottomNavigation() {
        val bottomNavigationView = requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.allPostsFragment -> {
                    findNavController().navigate(R.id.action_myPostsFragment_to_allPostsFragment)
                    true
                }
                R.id.addPostFragment -> {
                    findNavController().navigate(R.id.action_myPostsFragment_to_addPostFragment)
                    true
                }
                R.id.profileFragment -> {
                    val currentUser = FirebaseAuth.getInstance().currentUser
                    currentUser?.let { user ->
                        findNavController().navigate(R.id.action_myPostsFragment_to_profileFragment)
                    }
                    true
                }
                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        binding.progressBar.visibility = View.VISIBLE
        reloadData()
    }
    /**
     * Reloads the user's posts by refreshing the data from the repository.
     */
    private fun reloadData() {
        binding.progressBar.visibility = View.VISIBLE
        viewModel.refreshMyPosts()
        binding.progressBar.visibility = View.GONE
    }
}