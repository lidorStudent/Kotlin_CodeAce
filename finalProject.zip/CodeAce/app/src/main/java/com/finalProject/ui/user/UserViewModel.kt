package com.finalProject.ui.user

import android.util.Log
import android.util.Patterns
import androidx.lifecycle.*
import com.finalProject.data.models.User
import com.finalProject.data.repostories.UserRepository
import com.finalProject.utils.Resource
import kotlinx.coroutines.launch

/**
 * ViewModel for managing user-related operations.
 * This ViewModel handles user authentication, registration, and user data retrieval.
 *
 * @param userRep The repository instance for user data operations.
 */

class UserViewModel(private val userRep: UserRepository) : ViewModel(){
    // LiveData for tracking
    private val _userSignInStatus = MutableLiveData<Resource<User>>()
    val userSignInStatus: LiveData<Resource<User>> = _userSignInStatus

    private val _currentUser = MutableLiveData<Resource<User>>()
    val currentUser:LiveData<Resource<User>> = _currentUser

    private val _updateUser = MutableLiveData<Resource<Void>>()
    val updateUser: LiveData<Resource<Void>> = _updateUser


    init {
        // Initialize current user data
        viewModelScope.launch {
            _currentUser.postValue(Resource.Loading())
            _currentUser.postValue(userRep.currentUser())
        }
    }

    /**
     * Signs in a user with the provided email and password.
     *
     * @param userEmail The user's email.
     * @param userPass The user's password.
     */
    fun signInUser(userEmail:String, userPass:String) {
        if(userEmail.isEmpty() || userPass.isEmpty())
            _userSignInStatus.postValue(Resource.Error("Empty email or password"))
        else{
            _userSignInStatus.postValue(Resource.Loading())
            viewModelScope.launch {
                val loginResult = userRep.login(userEmail,userPass)
                _userSignInStatus.postValue(loginResult)
            }
        }
    }

    /**
     * Retrieves a user by their email.
     *
     * @param email The user's email.
     */
    fun getUserByEmail(email: String) {
        _currentUser.postValue(Resource.Loading())
        viewModelScope.launch {
            val user = userRep.getUserByEmail(email)
            _currentUser.postValue(user)
        }
    }

    private val _userRegistrationStatus = MutableLiveData<Resource<User>>()
    val userRegistrationStatus: LiveData<Resource<User>> = _userRegistrationStatus

    /**
     * Creates a new user with the provided details.
     *
     * @param userName The user's name.
     * @param userEmail The user's email.
     * @param userPass The user's password.
     * @param userImageUrl The URL of the user's profile image.
     */
    fun createUser(userName:String, userEmail:String, userPass:String, userImageUrl:String) {
        val error = if(userEmail.isEmpty() || userName.isEmpty() || userPass.isEmpty() || userImageUrl.isEmpty())
            "Empty Strings"
        else if(!Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
            "Not a valid email"
        }else null
        error?.let {
            _userRegistrationStatus.postValue(Resource.Error(it))
        }
        _userRegistrationStatus.value = Resource.Loading()
        viewModelScope.launch {
            val registrationResult = userRep.createUser(userName,userEmail,userPass, userImageUrl)
            _userRegistrationStatus.postValue(registrationResult)
        }
    }

    /**
     * Updates the user data.
     *
     * @param user The user object containing updated information.
     */
    fun updateUser(user: User){
        Log.i("maya", "userViewModel: $user")
        viewModelScope.launch {
            _updateUser.postValue(Resource.Loading())
            _updateUser.postValue(userRep.updateUser(user))
        }
    }

    /**
     * Signs out the current user.
     */
    fun signOut(){
        userRep.logout()
    }

    /**
     * Factory class for creating UserViewModel instances.
     *
     * @param repo The repository instance for user data operations.
     */
    class UserViewModelFactory(private val repo: UserRepository) : ViewModelProvider.NewInstanceFactory() {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return UserViewModel(repo) as T
        }
    }
}