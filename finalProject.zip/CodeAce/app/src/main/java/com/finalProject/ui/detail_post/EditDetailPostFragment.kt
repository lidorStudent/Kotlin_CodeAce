package com.finalProject.ui.detail_post

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.text.Editable
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.finalProject.R
import com.finalProject.data.models.FirebasePostModel
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.data.models.Post
import com.finalProject.databinding.FragmentEditDetailPostBinding
import com.finalProject.ui.all_posts.PostViewModel
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared

/**
 * This fragment allows the user to edit an existing post.
 * It loads the current post data and provides UI elements for updating the topic, additional text, and image.
 * The user can also delete the post from this fragment.
 */
class EditDetailPostFragment  : Fragment() {
    // Retrieve the post ID from the navigation arguments
    private val args: EditDetailPostFragmentArgs by navArgs()
    // Binding object for the fragment's layout
    private var binding: FragmentEditDetailPostBinding by autoCleared()
    // ViewModel instance for managing post-related data
    private val viewModel: PostViewModel by viewModels {
        PostViewModel.PostViewModelFactory(FirebaseUserModel(), FirebasePostModel())
    }
    // Variables to store post data
    private var postID: String? = null
    private var imageUri: Uri? = null
    private lateinit var currentImageUrl: String
    private lateinit var publisher: String
    private lateinit var publisherEmail: String
    // Activity result launcher for picking an image
    private val pickItemLauncher : ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) {
            if (it != null) {
                binding.imageView.setImageURI(it)
                requireActivity().contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                imageUri = it
            } else {
                findNavController().popBackStack(R.id.addPostFragment, false)
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentEditDetailPostBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val postId = args.postId

        // Load existing post data
        loadPostData(postId)

        // Set up click listeners for buttons
        binding.btnSelectImage.setOnClickListener {
            pickItemLauncher.launch(arrayOf("image/*"))
        }

        binding.btnCancel.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.btnDeletePost.setOnClickListener {
            // Delete the post and navigate back
            viewModel.getPost.value?.let {
                if (it is Resource.Success) {
                    val post = it.data
                    if (post != null) {
                        viewModel.deletePost(post)
                        findNavController().navigate(R.id.action_editPostFragment_to_allPostsFragment)
                    }
                }
            }
        }

        binding.btnSave.setOnClickListener {
            updatePost()
        }

        setupBottomNavigation()
    }

    /**
     * Loads the existing post data into the UI fields for editing.
     */
    private fun loadPostData(postId: String) {
        viewModel.getPostById(postId)
        viewModel.chosenPost.observe(viewLifecycleOwner) {
            when(it){
                is Resource.Loading ->{
                    binding.progressBar.isVisible = true
                }
                is Resource.Success ->{
                    binding.progressBar.isVisible = false
                    val post = it.data
                    if(post != null){
                        binding.editTextTopic.text = post.topicName.toEditable()
                        binding.editTextAdditionalText.text = post.additionalText.toEditable()
                        Glide.with(this).load(post.imageUrl).into(binding.imageView)
                        currentImageUrl = post.imageUrl.toString()
                        publisher = post.publisher.toString()
                        publisherEmail = post.publisherEmail.toString()
                        postID = post.postid.toString()
                    }
                }
                is Resource.Error ->{
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    /**
     * Updates the post with the new data from the UI fields.
     */
    private fun updatePost() {
        // Update the post with the new data from the UI fields
        val topic = binding.editTextTopic.text.toString().trim()
        val additionalText = binding.editTextAdditionalText.text.toString().trim()
        // Validate input fields
        if (topic.isBlank() || additionalText.isBlank() || (imageUri == null && currentImageUrl.isEmpty())) {
            Toast.makeText(requireContext(), R.string.fill_all, Toast.LENGTH_SHORT).show()
            return
        }
        // Create an updated Post object with the new data
        val updatedPost = Post(
            postID!!,
            publisher,
            publisherEmail,
            topic,
            additionalText,
            currentImageUrl
        )
        // Update the post and navigate back to AllPostsFragment
        viewModel.updatePost(updatedPost)
        findNavController().navigate(R.id.action_editPostFragment_to_allPostsFragment)
    }

    /**
     * Sets up the bottom navigation view for navigating between different fragments.
     */
    private fun setupBottomNavigation() {
        val bottomNavigationView =
            requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.allPostsFragment -> {
                    // Navigate to the user allPosts fragment
                    findNavController().navigate(R.id.action_editPostFragment_to_allPostsFragment)
                    true
                }
                R.id.addPostFragment -> {
                    // Navigate to the add post fragment
                    findNavController().navigate(R.id.action_editPostFragment_to_addPostFragment)
                    true
                }
                R.id.myPostsFragment ->{
                    findNavController().navigate(R.id.action_editPostFragment_to_myPostsFragment)
                    true
                }
                R.id.profileFragment -> {
                    // Navigate to profile
                    findNavController().navigate(R.id.action_editPostFragment_to_profileFragment)
                    true
                }
                else -> false
            }
        }
    }
    /**
     * Extension function to convert a String to an Editable object.
     */
    fun String.toEditable(): Editable = Editable.Factory.getInstance().newEditable(this)

}