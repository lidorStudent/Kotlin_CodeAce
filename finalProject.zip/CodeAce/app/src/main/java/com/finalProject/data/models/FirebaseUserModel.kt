package com.finalProject.data.models

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.finalProject.data.repostories.UserRepository
import com.finalProject.utils.Resource
import com.finalProject.utils.safeCall
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseUserModel : UserRepository {

    private val firebaseAuth = FirebaseAuth.getInstance()
    private val userRef = FirebaseFirestore.getInstance().collection("users")
    override suspend fun currentUser(): Resource<User> {
        return withContext(Dispatchers.IO) {
            safeCall {
                val currentUser = firebaseAuth.currentUser
                if (currentUser != null) {
                    val user = userRef.document(currentUser.uid).get().await().toObject(User::class.java)
                    Resource.Success(user!!)
                } else {
                    Resource.Error("User not logged in")
                }
            }
        }
    }

    override suspend fun login(email: String, password: String): Resource<User> {
        return withContext(Dispatchers.IO) {
            safeCall {
                Log.d("maya,","before signIn")
                val result = firebaseAuth.signInWithEmailAndPassword(email, password).await()
                Log.d("maya" ,"before get user " + result.user?.uid)
                val user = userRef.document(result.user?.uid!!).get().await().toObject(User::class.java)!!
                Log.d("maya", "user: " + user.toString())
                Resource.Success(user)
            }
        }
    }

    override suspend fun createUser(
        userName: String,
        userEmail: String,
        userPassword: String,
        userImageUrl: String
    ): Resource<User> {
        return withContext(Dispatchers.IO) {
            safeCall {
                val registrationResult = firebaseAuth.createUserWithEmailAndPassword(userEmail, userPassword).await()
                val userId = registrationResult.user?.uid!!
                val newUser = User(userName, userEmail, userImageUrl)
                userRef.document(userId).set(newUser).await()
                Resource.Success(newUser)
            }
        }
    }

    override suspend fun updateUser(user: User)= withContext(Dispatchers.IO) {
        safeCall {
            Log.i("maya", "userFirebase: $user")
            val userID = firebaseAuth.currentUser?.uid!!
            val update = userRef.document(userID).set(user.json).await()
            Log.i("maya", "updateFirebase: $update")
            Resource.Success(update)
        }
    }

    override fun logout() {
        firebaseAuth.signOut()
    }

    override fun getUserEmail(): String? {
        return firebaseAuth.currentUser?.email
    }

    override suspend fun getUserByEmail(email: String): Resource<User> {
        return withContext(Dispatchers.IO) {
            safeCall {
                val res = userRef.whereEqualTo("email", email).get().await()
                if (res != null && !res.isEmpty) {
                    val user = res.toObjects(User::class.java)[0]
                    Resource.Success(user)
                } else {
                    Resource.Error("User not found")
                }
            }
        }
    }
}