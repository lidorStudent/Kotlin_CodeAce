package com.finalProject.ui.all_posts

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.finalProject.data.models.Post
import com.finalProject.data.repostories.UserRepository
import com.finalProject.data.repostories.PostRepository
import PostsRecyclerAdapter
import android.widget.Toast
import androidx.core.view.isVisible
import com.finalProject.R
import com.finalProject.databinding.FragmentAllPostsBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.ItemTouchHelper
import com.finalProject.data.models.FirebasePostModel
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar


class AllPostsFragment : Fragment() {

    private var binding: FragmentAllPostsBinding by autoCleared()
    private val viewModel: PostViewModel by viewModels {
        PostViewModel.PostViewModelFactory(FirebaseUserModel(),FirebasePostModel())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentAllPostsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Set up the RecyclerView with a LinearLayoutManager and the PostsRecyclerAdapter
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = PostsRecyclerAdapter(object : PostsRecyclerAdapter.PostClickListener{
            override fun onPostClick(post: Post) {
                // Navigate to the DetailPostFragment when a post is clicked
                val postId = post.postid
                postId.let {
                    val action =
                        AllPostsFragmentDirections.actionAllPostsFragmentToDetailPostFragment(postId)
                    findNavController().navigate(action)
                }
            }
            override fun onPostLongClick(post: Post) {
            }
        })
        // Set up the SwipeRefreshLayout to refresh the data when swiped down
        binding.pullToRefresh.setOnRefreshListener {
            reloadData()
        }
        // Observe the posts LiveData and update the RecyclerView accordingly
        viewModel.posts.observe(viewLifecycleOwner){
            when(it){
                is Resource.Loading ->{
                    binding.progressBar.isVisible = true
                }
                is Resource.Success ->{
                    binding.progressBar.isVisible = false
                    binding.pullToRefresh.isRefreshing = false
                    (binding.recycler.adapter as PostsRecyclerAdapter).setPosts(it.data!!)
                }
                is Resource.Error ->{
                    binding.progressBar.isVisible = false
                    binding.pullToRefresh.isRefreshing = false
                    Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
        // Observe the addPost LiveData and handle the result
        viewModel.addPost.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                }
                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),R.string.post_added,Toast.LENGTH_SHORT).show()
                    reloadData()
                }
                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }

            }
        }
        // Observe the deletePost LiveData and handle the result
        viewModel.deletePost.observe(viewLifecycleOwner) {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                }
                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),R.string.post_deleted,Toast.LENGTH_SHORT).show()
                    reloadData()
                }
                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(requireContext(),it.message,Toast.LENGTH_SHORT).show()
                }

            }
        }
        // Set up the bottom navigation view
        setupBottomNavigationView()
        // Set up the ItemTouchHelper for swiping to delete posts
        ItemTouchHelper(object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            )= makeFlag(ItemTouchHelper.ACTION_STATE_SWIPE, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT)

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val post = (binding.recycler.adapter as PostsRecyclerAdapter).postAt(viewHolder.adapterPosition)
                val canDelete = viewModel.currentUser.value?.data?.let {
                    if(it.email != post.publisherEmail) {
                        binding.recycler.adapter!!.notifyDataSetChanged()
                        Toast.makeText(requireContext(), R.string.can_delete ,Toast.LENGTH_SHORT).show()
                         return@let false
                    }
                     true
                } ?: run {
                    binding.recycler.adapter!!.notifyDataSetChanged()
                    Toast.makeText(requireContext(),  R.string.can_delete ,Toast.LENGTH_SHORT).show()
                    false
                }
                if (!canDelete) return
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.confirm_delete_title)
                    .setMessage(R.string.delete_item_message)
                    .setPositiveButton(R.string.delete) { dialog, _ ->
                        viewModel.deletePost(post)
                        dialog.dismiss()
                    }
                    .setNegativeButton(R.string.cancel) { dialog, _ ->
                        binding.recycler.adapter!!.notifyItemChanged(viewHolder.adapterPosition)
                        dialog.dismiss()
                    }
                    .setOnCancelListener {
                        binding.recycler.adapter!!.notifyItemChanged(viewHolder.adapterPosition)
                    }
                    .show()
            }
        }).attachToRecyclerView(binding.recycler)
    }
    // Sets up the bottom navigation view for navigating between different fragments.
    private fun setupBottomNavigationView() {
        val bottomNavigationView =
            requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.profileFragment -> {
                    findNavController().navigate(R.id.action_allPostsFragment_to_profileFragment)
                    true
                }
                R.id.addPostFragment -> {
                    findNavController().navigate(R.id.action_allPostsFragment_to_addPostFragment)
                    true
                }
                R.id.myPostsFragment -> {
                    findNavController().navigate(R.id.action_allPostsFragment_to_myPostsFragment)
                    true
                }
                else -> false
            }
        }
    }

    private fun reloadData() {
        binding.progressBar.visibility = View.VISIBLE
        viewModel.refreshPosts()
        binding.progressBar.visibility = View.GONE
    }
}
