package com.finalProject.ui.user

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.finalProject.R
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.databinding.FragmentSignupBinding
import com.finalProject.ui.MainActivity
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared


/**
 * A fragment for user registration.
 * This fragment handles user sign-up functionality, including selecting a profile picture,
 * entering user details, and creating a new user account in Firebase Authentication and Firestore.
 */
class SignUpFragment : Fragment() {

    private val viewModel: UserViewModel by viewModels {
        UserViewModel.UserViewModelFactory(FirebaseUserModel())
    }
    private var binding: FragmentSignupBinding by autoCleared()
    var currentImageUrl: String?= null

    /**
     * Inflates the layout for this fragment using view binding.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSignupBinding.inflate(inflater, container, false)
        binding.progressBar.isVisible = false


        return binding.root
    }

    /**
     * Called immediately after onCreateView has returned, but before any saved state has been restored in to the view.
     * Sets up click listeners for the login button, image upload button, and signup button.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Navigate back to the login screen
        binding.loginBtn.setOnClickListener {
            Navigation.findNavController(it).popBackStack()
        }
        // Show dialog for image selection
        binding.BtnUploadImage.setOnClickListener {
            showImageSelectionDialog()
        }
        // Register new user
        binding.signupBtn.setOnClickListener {
            val email = binding.email.text.toString().trim()
            val password = binding.password.text.toString().trim()
            val name = binding.fullName.text.toString()

            // Validate user inputs
            if (validateInputs(email, password, name, currentImageUrl)) {
                currentImageUrl?.let { it1 -> viewModel.createUser(name, email, password, it1) }
            }
        }

        viewModel.userRegistrationStatus.observe(viewLifecycleOwner) {
            when (it) {
                is Resource.Loading -> {
                    binding.progressBar.isVisible = true
                    binding.signupBtn.isEnabled = false
                }

                is Resource.Success -> {
                    binding.progressBar.isVisible = false
                    Toast.makeText(
                        requireContext(),
                        R.string.registration_successful,
                        Toast.LENGTH_SHORT
                    ).show()
                    Navigation.findNavController(requireView())
                        .navigate(R.id.action_signUpFragment_to_allPostsFragment)
                    (requireActivity() as MainActivity).setBottomBarVisibility(true)
                    (requireActivity() as MainActivity).setAddMenuItemVisibility(true)
                }

                is Resource.Error -> {
                    binding.progressBar.isVisible = false
                    binding.signupBtn.isEnabled = true
                    Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * Validates user inputs.
     * @return true if all inputs are valid, false otherwise.
     */
    private fun validateInputs(email: String, password: String, name: String, imageUrl: String?): Boolean {
        return if (email.isEmpty() || password.isEmpty() || name.isEmpty() || imageUrl.isNullOrEmpty() || password.length < 6) {
            Toast.makeText(context, R.string.fill_all_registration, Toast.LENGTH_SHORT).show()
            false
        }else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(context, R.string.not_vail_email, Toast.LENGTH_SHORT).show()
            false
        } else {
            true
        }
    }

    /**
     * Displays a dialog for the user to choose between picking an image from the gallery or selecting from predefined images.
     */
    private fun showImageSelectionDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.select_image_source)
            .setItems(arrayOf("Gallery", "Predefined Images")) { dialog, which ->
                when (which) {
                    0 -> openImagePicker() // Gallery
                    1 -> showPredefinedImagesDialog() // Predefined Images
                }
            }
            .setNegativeButton(R.string.cancel) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    /**
     * Opens the gallery for the user to pick an image.
     */
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_PICK_REQUEST_CODE)
    }

    /**
     * Displays a dialog with a grid of predefined images for the user to select.
     */
    private fun showPredefinedImagesDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_image_selection, null)
        val recyclerViewImages: RecyclerView = dialogView.findViewById(R.id.recyclerViewImage)

        recyclerViewImages.layoutManager = GridLayoutManager(requireContext(), 4)

        val imageUrls = listOf(
            // List of image URLs
            "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
            "https://thumbs.dreamstime.com/b/businessman-icon-vector-male-avatar-profile-image-profile-businessman-icon-vector-male-avatar-profile-image-182095609.jpg",
            "https://cdn1.vectorstock.com/i/1000x1000/06/70/brunette-businessman-avatar-man-face-profile-icon-vector-21960670.jpg",
            "https://static.vecteezy.com/system/resources/previews/019/896/012/original/female-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png",
            "https://w7.pngwing.com/pngs/4/736/png-transparent-female-avatar-girl-face-woman-user-flat-classy-users-icon.png",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvRBpwE6j59hC4-ASz6l1piuoNKjzc5MFBVzfRX6xp-g&s",
            "https://cdn-icons-png.flaticon.com/512/147/147137.png",
            "https://www.shareicon.net/data/512x512/2016/09/15/829453_user_512x512.png",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8pqpC6IgkvdxOH-qCcentLTmv_U4TeAVMPutepRWn9w&s",
            "https://www.svgrepo.com/show/382104/male-avatar-boy-face-man-user-3.svg",
            "https://w7.pngwing.com/pngs/340/946/png-transparent-avatar-user-computer-icons-software-developer-avatar-child-face-heroes.png",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMPzJXAxicQcYo0jMFCcFjvjLQJ7PHCrQXz3ErnfBiEg&s"
        )

        val adapter = ImageSelectionAdapter(imageUrls) { imageUrl ->
            currentImageUrl = imageUrl
            Glide.with(this).load(imageUrl).into(binding.imageView)
        }
        recyclerViewImages.adapter = adapter

        AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .setTitle(R.string.select_image)
            .setPositiveButton(R.string.confirm){ dialog, _ ->
                if(currentImageUrl != null){
                    dialog.dismiss()
                } else {
                    Toast.makeText(context, R.string.select_image, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel) { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    /**
     * Handles the result from the image picker intent.
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == IMAGE_PICK_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            // Get the URI of the selected image
            val selectedImageUri: Uri? = data.data
            // Convert the URI to a string and save it in currentImageUrl
            currentImageUrl = selectedImageUri.toString()
            // Use Glide to load the selected image into the ImageView
            Glide.with(this).load(selectedImageUri).into(binding.imageView)
        }
    }

    companion object {
        const val IMAGE_PICK_REQUEST_CODE = 123
    }
}