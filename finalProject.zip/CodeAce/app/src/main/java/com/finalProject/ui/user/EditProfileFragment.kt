package com.finalProject.ui.user

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.text.Editable
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.finalProject.R
import com.finalProject.data.models.FirebaseUserModel
import com.finalProject.data.models.User
import com.finalProject.databinding.FragmentEditProfileBinding
import com.finalProject.utils.Resource
import com.finalProject.utils.autoCleared
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.squareup.picasso.Picasso

/**
 * This fragment allows the user to edit their profile information, including their name, email, and profile picture.
 */
class EditProfileFragment : Fragment() {
    // Initialize the ImageView for displaying the profile picture
    private lateinit var imageView: ImageView
    // ViewModel instance for managing user-related data
    private val viewModel: UserViewModel by viewModels {
        UserViewModel.UserViewModelFactory(FirebaseUserModel())
    }
    // Binding object for the fragment's layout
    private var binding: FragmentEditProfileBinding by autoCleared()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentEditProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Call the preloading task when the fragment is created
        ImagePreloadingTask().execute()

        var currentImageUrl: String? = null

        // Observe the currentUser LiveData and update the UI with the user's information
        viewModel.currentUser.observe(viewLifecycleOwner){
            when(it) {
                is Resource.Loading ->{}
                is Resource.Success -> {
                    val user = it.data
                    binding.editTextName.text = user?.name?.toEditable()
                    binding.editTextEmail.text = user?.email?.toEditable()
                    currentImageUrl = user?.image
                    Glide.with(requireContext())
                        .load(user?.image)
                        .override(400, 400) // resize image
                        .centerCrop()
                        .into(binding.imageView1)
                }
                is Resource.Error -> {
                    Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
        // Set up the click listener for the "Upload Image" button
        binding.btnUploadImage.setOnClickListener {
            val dialogView = layoutInflater.inflate(R.layout.dialog_image_selection, null)
            val recyclerViewImages: RecyclerView = dialogView.findViewById(R.id.recyclerViewImage)
            // Show a dialog with a RecyclerView to select an image
            recyclerViewImages.layoutManager = GridLayoutManager(requireContext(), 4)

            val imageUrls = listOf(
                // List of sample image URLs
                "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
                "https://thumbs.dreamstime.com/b/businessman-icon-vector-male-avatar-profile-image-profile-businessman-icon-vector-male-avatar-profile-image-182095609.jpg",
                "https://cdn1.vectorstock.com/i/1000x1000/06/70/brunette-businessman-avatar-man-face-profile-icon-vector-21960670.jpg",
                "https://static.vecteezy.com/system/resources/previews/019/896/012/original/female-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png",
                "https://w7.pngwing.com/pngs/4/736/png-transparent-female-avatar-girl-face-woman-user-flat-classy-users-icon.png",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvRBpwE6j59hC4-ASz6l1piuoNKjzc5MFBVzfRX6xp-g&s",
                "https://cdn-icons-png.flaticon.com/512/147/147137.png",
                "https://www.shareicon.net/data/512x512/2016/09/15/829453_user_512x512.png",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8pqpC6IgkvdxOH-qCcentLTmv_U4TeAVMPutepRWn9w&s",
                "https://www.svgrepo.com/show/382104/male-avatar-boy-face-man-user-3.svg",
                "https://w7.pngwing.com/pngs/340/946/png-transparent-avatar-user-computer-icons-software-developer-avatar-child-face-heroes.png",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMPzJXAxicQcYo0jMFCcFjvjLQJ7PHCrQXz3ErnfBiEg&s"
            )

            val adapter = ImageSelectionAdapter(imageUrls) { imageUrl ->
                currentImageUrl = imageUrl
                // Load the selected image directly into the ImageView
                Glide.with(requireContext()).load(imageUrl).into(binding.imageView1)

            }
            recyclerViewImages.adapter = adapter

            // Notify the adapter that data has changed
            adapter.notifyDataSetChanged()

            val dialog = AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .setTitle("Select Image")
                .setNegativeButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                }
                .create()
            dialog.show()
        }
        // Set up the click listener for the "Update" button
        binding.buttonUpdate.setOnClickListener {
            val name = binding.editTextName.text.toString()
            val email = binding.editTextEmail.text.toString()
            if (name.isBlank()) {
                // Show an error message to the user, for example, using a Toast
                Toast.makeText(requireContext(), R.string.fill_all, Toast.LENGTH_SHORT)
                    .show()
            } else {
                // Create an updated User object with the new data
                val updatedUser = User(name, email, currentImageUrl!!)
                // Update the user's information and navigate back to the ProfileFragment
                viewModel.updateUser(updatedUser)
                findNavController().navigate(R.id.action_editProfileFragment_to_profileFragment)
            }
        }

        // Set up the click listener for the "Cancel" button
        binding.buttonCancel.setOnClickListener {
            Navigation.findNavController(it).popBackStack()
        }
        // Set up the bottom navigation view
        val bottomNavigationView =
            requireActivity().findViewById<BottomNavigationView>(R.id.mainActivityBottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.allPostsFragment -> {
                    // Navigate to the user allPosts fragment
                    findNavController().navigate(R.id.action_editPostFragment_to_allPostsFragment)
                    true
                }
                R.id.addPostFragment -> {
                    // Navigate to the add post fragment
                    findNavController().navigate(R.id.action_editPostFragment_to_addPostFragment)
                    true
                }
                R.id.myPostsFragment -> {
                    findNavController().navigate(R.id.action_editPostFragment_to_myPostsFragment)
                    true
                }
                R.id.profileFragment -> {
                    // Navigate to profile
                    findNavController().navigate(R.id.action_editPostFragment_to_profileFragment)
                    true
                }
                else -> false
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == IMAGE_PICK_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            val selectedImageUri = data.data
            Picasso.get().load(selectedImageUri).into(imageView as ImageView)
        }
    }

    companion object {
        const val IMAGE_PICK_REQUEST_CODE = 123
    }
    /**
     * An AsyncTask to preload images in the background for better performance.
     */
    inner class ImagePreloadingTask : AsyncTask<Void, Void, Unit>() {
        override fun doInBackground(vararg params: Void?) {
            preloadImages()
        }

        private fun preloadImages() {
            val imageUrls = listOf(
                "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
                "https://thumbs.dreamstime.com/b/businessman-icon-vector-male-avatar-profile-image-profile-businessman-icon-vector-male-avatar-profile-image-182095609.jpg",
                "https://cdn1.vectorstock.com/i/1000x1000/06/70/brunette-businessman-avatar-man-face-profile-icon-vector-21960670.jpg",
                "https://static.vecteezy.com/system/resources/previews/019/896/012/original/female-user-avatar-icon-in-flat-design-style-person-signs-illustration-png.png",
                "https://w7.pngwing.com/pngs/4/736/png-transparent-female-avatar-girl-face-woman-user-flat-classy-users-icon.png",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvRBpwE6j59hC4-ASz6l1piuoNKjzc5MFBVzfRX6xp-g&s",
                "https://cdn-icons-png.flaticon.com/512/147/147137.png",
                "https://www.shareicon.net/data/512x512/2016/09/15/829453_user_512x512.png",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8pqpC6IgkvdxOH-qCcentLTmv_U4TeAVMPutepRWn9w&s",
                "https://www.svgrepo.com/show/382104/male-avatar-boy-face-man-user-3.svg",
                "https://w7.pngwing.com/pngs/340/946/png-transparent-avatar-user-computer-icons-software-developer-avatar-child-face-heroes.png",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMPzJXAxicQcYo0jMFCcFjvjLQJ7PHCrQXz3ErnfBiEg&s"
            )
            for (imageUrl in imageUrls) {
                Picasso.get().load(imageUrl).fetch()
            }
        }
    }

    /**
     * Extension function to convert a String to an Editable object.
     */
    fun String.toEditable(): Editable = Editable.Factory.getInstance().newEditable(this)
}