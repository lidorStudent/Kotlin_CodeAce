package com.finalProject.data.local_db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.finalProject.data.models.Post

@Dao
interface PostDao {

    @Query("SELECT * FROM posts")
    fun getAll(): LiveData<List<Post>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertPost(vararg post: Post)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg post: Post)

    @Delete
    fun deletePost(post: Post)

    @Query("SELECT * FROM posts WHERE postid =:id")
    infix fun getPostById(id: String):  LiveData<Post>

    @Query("SELECT * FROM posts WHERE publisherEmail = :publisherEmail")
    fun getPostsByPublisherEmail(publisherEmail: String): LiveData<List<Post>>

    @Update
    fun updatePost(post: Post)
}